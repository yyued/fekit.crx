window.cleanCss = require('clean-css')
window.uglifyJs = require('uglify-js')